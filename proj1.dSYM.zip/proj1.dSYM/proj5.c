//Write a C program to print your name, date of birth. and mobile number
#include<Stdio.h>
int main()
{
    printf("my name: Raghav\n");
    printf("my dob: 22,08,2004\n");
    printf("my mobile number: 7742609501234\n");
    return 0;

}